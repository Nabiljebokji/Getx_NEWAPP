import 'package:get/get.dart';
import 'package:tasktracker/data/datasourse/home/home_service.dart';
import 'package:tasktracker/data/models/login/login_response_model.dart';
import 'package:tasktracker/utils/class/statusrequest.dart';
import 'package:tasktracker/utils/config/environment.dart';
import 'package:tasktracker/utils/functions/handingdatacontroller.dart';
import 'package:tasktracker/utils/helper/logger.dart';
import 'package:tasktracker/utils/services/services.dart';

class HomeController extends GetxController {
  late Rx<StatusRequest> statusRequest = StatusRequest.none.obs;
  Rx<StatusRequest> get getStatusRequest => statusRequest;
  HomeData homeData = HomeData(Get.find());
  MyServices myServiceController = Get.find<MyServices>();
  List<LoginResponseModel> userList = [];

  @override
  void onInit() {
    statusRequest.value = StatusRequest.loading;
    super.onInit();
  }

  getUserPermissions() async {
    statusRequest.value = StatusRequest.loading;
    var userId =
        myServiceController.sharedPreferences!.getString(Environment.userId);
    var response = await homeData.getUserPermissions(userId);
    statusRequest.value = handlingData(response);
    if (StatusRequest.success == statusRequest.value) {
      userList.clear();
      userList.add(LoginResponseModel.fromJson(response));

      myServiceController.sharedPreferences!.setString(
          Environment.accessToken, userList.first.token!.accessToken!);
      myServiceController.sharedPreferences!.setString(
          Environment.refreshToken, userList.first.token!.refreshToken!);
      myServiceController.sharedPreferences!
          .setString(Environment.userId, userList.first.userId!);
      myServiceController.sharedPreferences!
          .setString(Environment.customerId, userList.first.customerId!);
    } else {
      ResponseHelper resp = response;
      Logger.error(resp.serverErrorModel!.message.toString());
      // snackBar(
      //     title: "Hata!",
      //     body: resp.serverErrorModel!.message.toString(),
      //     isErrorIcon: true);
      statusRequest.value = StatusRequest.none;
    }
    update();
  }
}
