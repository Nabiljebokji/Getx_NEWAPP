import 'package:get/get.dart';
import 'package:tasktracker/utils/helper/logger.dart';

class FinishDialogController extends GetxController {
  double starsbar1 = 3.5;
  double starsbar2 = 3.5;
  double starsbar3 = 3.5;

  late bool _finishedPressed = false;
  bool get finishedPressed => _finishedPressed;

  setFinishedPressed(bool itis) {
    _finishedPressed = itis;
    update();
  }

  changeStarsValue1(value) {
    Logger.success("1");
    starsbar1 = value;
    update();
  }

  changeStarsValue2(value) {
    Logger.success("2");
    starsbar2 = value;
    update();
  }

  changeStarsValue3(value) {
    Logger.success("3");
    starsbar3 = value;
    update();
  }
}
