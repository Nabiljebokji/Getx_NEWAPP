// import 'package:qr_bar_code_scanner_dialog/qr_bar_code_scanner_dialog.dart';
import 'dart:convert';

import 'package:qr_bar_code_scanner_dialog/qr_bar_code_scanner_dialog.dart';
import 'package:tasktracker/data/models/login/get_personnel_userid_list_model.dart';
import 'package:tasktracker/data/models/login/get_roles_to_user_model.dart';
import 'package:tasktracker/data/models/login/get_user_permissions_model.dart';
import 'package:tasktracker/data/models/login/login_response_model.dart';
import 'package:tasktracker/data/models/shared/qrinfo.dart';
import 'package:tasktracker/utils/functions/handingdatacontroller.dart';
import 'package:tasktracker/data/datasourse/login/login_service.dart';
import 'package:tasktracker/data/models/login/login_model.dart';
import 'package:tasktracker/utils/class/statusrequest.dart';
import 'package:tasktracker/utils/config/environment.dart';
import 'package:tasktracker/utils/services/services.dart';
import 'package:tasktracker/utils/routes/app_routes.dart';
import 'package:tasktracker/utils/helper/logger.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class LoginController extends GetxController {
  TextEditingController? userNameController = TextEditingController();
  TextEditingController? passWordController = TextEditingController();
  TextEditingController? baseNameUrlController = TextEditingController();
  TextEditingController? institutionidController = TextEditingController();

  MyServices myServiceController = Get.find<MyServices>();
  LoginData loginData = LoginData(Get.find());
  List<LoginResponseModel> userList = [];
  List<GetUserPermissionsModel> permissionList = [];
  List<GetRolesToUserModel> userRolesList = [];
  List<GetPersonnelUserIdListModel> personnelUserIdList = [];

  late Rx<StatusRequest> statusRequest = StatusRequest.none.obs;
  Rx<StatusRequest> get getStatusRequest => statusRequest;
  LoginModel? loginmodel;
  final _qrBarCodeScannerDialogPlugin = QrBarCodeScannerDialog();
  var userId;
  checkLogin() async {
    if (kDebugMode) {
      baseNameUrlController!.text = Environment.baseName;
      institutionidController!.text = Environment.sabitKurumId;
      userNameController!.text = Environment.fakeName;
      passWordController!.text = Environment.fakePassWord;
    }
    if (baseNameUrlController!.text != "") {
      if (userNameController!.text != "" && passWordController!.text != "") {
        statusRequest.value = StatusRequest.loading;
        loginmodel = LoginModel(
            usernameOrEmail: userNameController!.text,
            password: passWordController!.text);
        debugPrint(
            "${"${"KULLANICI: " "${userNameController!.text}"}// PAROLA: " "${passWordController!.text}"}// URL: ${baseNameUrlController!.text}//SABITKURUMID: ${institutionidController!.text}");

        await loginService();

        if (StatusRequest.success == statusRequest.value) {
          myServiceController.sharedPreferences!.setString(
              Environment.backendBaseName, baseNameUrlController!.text);
          myServiceController.sharedPreferences!.setString(
              Environment.sabitKurumId, institutionidController!.text);
          myServiceController.sharedPreferences!
              .setString(Environment.userName, userNameController!.text);
          myServiceController.secureStorage
              .writeSecureData(Environment.passWord, passWordController!.text);

          Get.offNamed(AppRoutes.home);
        }
      } else {
        snackBar(
          title: "Hata!.",
          body: "K.Adı veya şifre Boş Olamaz.",
          isErrorIcon: true,
        );
      }
    } else {
      snackBar(title: "Hata!.", body: "karekod okunmadı.", isErrorIcon: true);
    }
  }

  snackBar({
    String? title,
    String? body,
    Color? backgroundColor,
    required bool? isErrorIcon,
  }) {
    return Get.snackbar(
      title!,
      body!,
      snackPosition: SnackPosition.BOTTOM,
      backgroundColor: backgroundColor ?? Colors.white,
      colorText: Colors.black,
      borderRadius: 10,
      margin: EdgeInsets.all(10),
      icon: isErrorIcon == true
          ? Icon(Icons.error, color: Colors.red[900])
          : Icon(Icons.check_circle_outline, color: Colors.green),
      shouldIconPulse: true,
      barBlur: 20,
      isDismissible: true,
      duration: Duration(seconds: 3),
      // overlayBlur: 10,
      forwardAnimationCurve: Curves.easeOutBack,
      reverseAnimationCurve: Curves.easeInBack,
      animationDuration: Duration(milliseconds: 500),
    );
  }

  loginService() async {
    statusRequest.value = StatusRequest.loading;
    var response = await loginData.postLogin(loginmodel);
    statusRequest.value = handlingData(response);
    if (StatusRequest.success == statusRequest.value) {
      userList.clear();
      userList.add(LoginResponseModel.fromJson(response));

      myServiceController.sharedPreferences!.setString(
          Environment.accessToken, userList.first.token!.accessToken!);
      myServiceController.sharedPreferences!.setString(
          Environment.refreshToken, userList.first.token!.refreshToken!);
      myServiceController.sharedPreferences!
          .setString(Environment.userId, userList.first.userId!);
      myServiceController.sharedPreferences!
          .setString(Environment.customerId, userList.first.customerId!);
      userId = userList.first.userId!;
      await getUserPermissions();
    } else {
      ResponseHelper resp = response;
      Logger.error(resp.serverErrorModel!.message.toString());
      snackBar(
          title: "Hata!",
          body: resp.serverErrorModel!.message.toString(),
          isErrorIcon: true);
      statusRequest.value = StatusRequest.none;
    }
    update();
  }

  getUserPermissions() async {
    statusRequest.value = StatusRequest.loading;

    var response = await loginData.getUserPermissions(userId);
    statusRequest.value = handlingData(response);

    if (StatusRequest.success == statusRequest.value) {
      permissionList.clear();
      permissionList.add(GetUserPermissionsModel.fromJson(response));
      permissionList.map((e) {
        Logger.info("try this thig ${e.toJson().toString()}");
        return e.toJson();
      });
      // myServiceController.sharedPreferences!.setString(
      //     Environment.permissions, GetUserPermissions().toJson().toString());
      await getRolesToUser();
    } else {
      ResponseHelper resp = response;
      Logger.error(resp.serverErrorModel!.message.toString());
      snackBar(
          title: "Hata!",
          body: resp.serverErrorModel!.message.toString(),
          isErrorIcon: true);
      statusRequest.value = StatusRequest.none;
    }
    update();
  }

  getRolesToUser() async {
    statusRequest.value = StatusRequest.loading;

    var response = await loginData.getRolesToUser(userId);
    statusRequest.value = handlingData(response);

    if (StatusRequest.success == statusRequest.value) {
      userRolesList.clear();
      userRolesList.add(GetRolesToUserModel.fromJson(response));
      myServiceController.sharedPreferences!.setString(
          Environment.userRole, userRolesList.first.userRoles!.first);
      await getPersonnelUserIdList();
    } else {
      ResponseHelper resp = response;
      Logger.error(resp.serverErrorModel!.message.toString());
      snackBar(
          title: "Hata!",
          body: resp.serverErrorModel!.message.toString(),
          isErrorIcon: true);
      statusRequest.value = StatusRequest.none;
    }
    update();
  }

  getPersonnelUserIdList() async {
    statusRequest.value = StatusRequest.loading;

    var response = await loginData.getPersonnelUserIdList(userId);
    statusRequest.value = handlingData(response);

    if (StatusRequest.success == statusRequest.value) {
      personnelUserIdList.clear();
      personnelUserIdList.add(GetPersonnelUserIdListModel.fromJson(response));
    } else {
      ResponseHelper resp = response;
      Logger.error(resp.serverErrorModel!.message.toString());
      snackBar(
          title: "Hata!",
          body: resp.serverErrorModel!.message.toString(),
          isErrorIcon: true);
      statusRequest.value = StatusRequest.none;
    }
    update();
  }

  qrCodeScan(context) async {
    _qrBarCodeScannerDialogPlugin.getScannedQrBarCode(
        context: context,
        onCode: (code) {
          try {
            var login = QrInfo.fromJson(json.decode(code.toString()));

            myServiceController.sharedPreferences!
                .setString(Environment.baseName, login.url!);

            myServiceController.sharedPreferences!.setString(
                Environment.sabitKurumId, login.sabitKurumId.toString());

            myServiceController.sharedPreferences!
                .setString(Environment.userName, login.userName.toString());

            userNameController!.text = login.userName.toString();
            snackBar(
              title: "Başarlı",
              body: "Ayarlar Alındı.",
              isErrorIcon: false,
            );
          } catch (e) {
            snackBar(
              title: "Başarsız",
              body: "Qr Bilgisi Yanlış!",
              isErrorIcon: true,
            );
          }
        });
  }
}
