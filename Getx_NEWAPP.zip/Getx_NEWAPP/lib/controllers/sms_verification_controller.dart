import 'package:get/get.dart';

class SmsVerificationController extends GetxController {
  bool buttonEnabled = false;

  changeButtonStatus(bool enabled) {
    buttonEnabled = enabled;
    update();
  }
}
