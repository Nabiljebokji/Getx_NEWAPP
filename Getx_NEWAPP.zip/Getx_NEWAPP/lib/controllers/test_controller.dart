// import 'package:get/get.dart';
// import 'package:tasktracker/data/datasourse/remote/test_data.dart';
// import 'package:tasktracker/utils/class/statusrequest.dart';
// import 'package:tasktracker/utils/functions/handingdatacontroller.dart';
// import 'package:tasktracker/utils/helper/logger.dart';

// class TestController extends GetxController {
//   TestData testData = TestData(Get.find());

//   List data = [];

//   late StatusRequest statusRequest;

//   @override
//   void onInit() {
//     getData();
//     super.onInit();
//   }

//   getData() async {
//     statusRequest = StatusRequest.loading;

//     var response = await testData.getData();

//     Logger.info("=============================== Controller $response ");

//     statusRequest = handlingData(response);

//     if (StatusRequest.success == statusRequest) {
//       // Start backend
//       if (response['status'] == "success") {
//         data.addAll(response['data']);
//       } else {
//         statusRequest = StatusRequest.failure;
//       }
//       // End
//     }
//     update();
//   }
// }
