import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:tasktracker/utils/constants/colors/app_colors.dart';
import 'package:tasktracker/utils/routes/app_routes.dart';

class CustomDrawer extends StatelessWidget {
  const CustomDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          DrawerHeader(
            decoration: BoxDecoration(
              color: AppColors.greenish,
            ),
            child: Text('Drawer Header'),
          ),
          ListTile(
            title: Text('Home'),
            onTap: () {
              if (Get.currentRoute != AppRoutes.home) {
                Get.toNamed(AppRoutes.home);
              } else {
                Get.back();
              }
            },
          ),
          ListTile(
            title: Text('Logout'),
            onTap: () {
              Get.offNamed(AppRoutes.login);
            },
          ),
        ],
      ),
    );
  }
}
