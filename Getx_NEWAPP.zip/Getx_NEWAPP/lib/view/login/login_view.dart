// ignore_for_file: deprecated_member_use

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';
import 'package:tasktracker/controllers/login/login_controller.dart';
import 'package:tasktracker/utils/class/handlingdataview.dart';
import 'package:tasktracker/utils/class/statusrequest.dart';
import 'package:tasktracker/utils/constants/colors/app_colors.dart';
import 'package:tasktracker/utils/constants/images/app_images.dart';

class LoginView extends StatefulWidget {
  const LoginView({super.key});

  @override
  State<LoginView> createState() => _LoginViewState();
}

class _LoginViewState extends State<LoginView> {
  final LoginController controller = Get.find<LoginController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.white,
      body: SingleChildScrollView(
        physics: BouncingScrollPhysics(),
        child: GestureDetector(
          onTap: () {
            FocusManager.instance.primaryFocus?.unfocus();
          },
          child: SizedBox(
            height: Get.height,
            child: HandlingView(widget: body(context), widget2: loadingBody()),
          ),
        ),
      ),
    );
  }

  Widget body(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.max,
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          // crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            kDebugMode
                ? Row(
                    children: [
                      Padding(
                        padding: EdgeInsets.only(left: 10, top: 40),
                        child: IconButton(
                            alignment: Alignment.center,
                            onPressed: () {
                              Get.dialog(showMaterialDialog());
                            },
                            icon: Icon(
                              Icons.settings,
                              color: AppColors.blue,
                            )),
                      ),
                    ],
                  )
                : Container(),
            SizedBox(height: 20),
            Center(
              child: Text("Hasta Değerine Saygı Göster,".tr,
                  // child: Text("1".tr,
                  style: TextStyle(
                      color: AppColors.blue,
                      fontSize: 20,
                      fontWeight: FontWeight.bold)),
            ),
            Center(
              child: Text("Geleceği Birlikte İnşa Et!".tr,
                  style: TextStyle(
                      color: AppColors.bluesh,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      overflow: TextOverflow.clip)),
            ),
            SizedBox(height: 10),
            Padding(
              padding: EdgeInsets.only(top: 14.0, left: 14, right: 14),
              child: Text(
                "hastanemizin giriş sistemi hoş geldiniz! Hastanemizde, personelimizin bakımını önemsiyor ve potansiyellerini en üst düzeye çıkarmalarını teşvik ediyoruz. Bu giriş sistemi, bizi bir araya getiren ve gelişmemizi sağlayan öncü vizyonumuzu yansıtır."
                    .tr,
                style: TextStyle(
                  color: AppColors.blue,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
        Column(
          children: [
            textFieldWidget(
              controller: controller.userNameController,
              hintText: "Kullancı Adı".tr,
              icons: Icons.person,
            ),
            textFieldWidget(
              controller: controller.passWordController,
              hintText: "Parola".tr,
              icons: Icons.lock_person,
            ),
          ],
        ),
        ElevatedButton(
            onPressed: () {
              controller.checkLogin();
            },
            style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all(AppColors.blue),
              shape: MaterialStateProperty.all(
                RoundedRectangleBorder(
                    borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(15),
                  bottomRight: Radius.circular(15),
                )),
              ),
              minimumSize: MaterialStateProperty.all(
                  Size(220, 50)), // Example width: 100
            ),
            child: Text(
              "Giriş Yap".tr,
              style: TextStyle(color: Colors.white, fontSize: 20),
            )),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Padding(
              padding: const EdgeInsets.all(18.0),
              child: Row(
                children: [
                  SizedBox(
                      height: 60,
                      width: 60,
                      child: SvgPicture.asset(AppImages.logo,
                          color: Color.fromARGB(255, 218, 16, 2))),
                  SizedBox(
                    height: 60,
                    width: 60,
                    child: SvgPicture.asset(AppImages.kardelenYazilim),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(18.0),
              child: GestureDetector(
                onTap: () {
                  controller.qrCodeScan(context);
                },
                child: Image.asset(
                  AppImages.qrCode,
                  height: Get.height * 0.1,
                  width: Get.width * 0.2,
                  alignment: Alignment.bottomCenter,
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget loadingBody() {
    return GetX<LoginController>(
      init: LoginController(),
      builder: (getcontroller) {
        return Visibility(
            visible:
                getcontroller.getStatusRequest.value == StatusRequest.loading,
            child: Center(
                child:
                    Lottie.asset(AppImages.loading, width: 100, height: 100)));
      },
    );
  }

  textFieldWidget({
    IconData? icons,
    String? hintText,
    TextEditingController? controller,
  }) {
    return Padding(
      padding: const EdgeInsets.only(left: 20.0, right: 40, top: 10),
      child: Row(
        children: [
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Icon(
              icons,
              color: AppColors.blue,
            ),
          ),
          SizedBox(width: 8),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                boxShadow: const [
                  BoxShadow(
                      color: Colors.black,
                      blurRadius: 0.1,
                      spreadRadius: 0.1,
                      blurStyle: BlurStyle.inner)
                ],
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(15),
                    bottomRight: Radius.circular(15)),
                color: Colors.white,
              ),
              child: TextField(
                controller: controller,
                decoration: InputDecoration(
                  hintText: hintText,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.only(
                        bottomRight: Radius.circular(15),
                        topLeft: Radius.circular(15)),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  showMaterialDialog() {
    return AlertDialog(
      backgroundColor: Color(0xffF2F2F2),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Colors.white,
                  border: Border.all(
                    color: Colors.grey.shade200,
                    width: 1.0,
                  ),
                  boxShadow: const [
                    BoxShadow(
                      color: Color.fromRGBO(196, 196, 196, .3),
                      blurRadius: 10,
                      offset: Offset(0, 10),
                    )
                  ]),
              child: TextField(
                style: TextStyle(color: Colors.black),
                controller: controller.baseNameUrlController,
                decoration: InputDecoration(
                    border: InputBorder.none,
                    focusedBorder: InputBorder.none,
                    enabledBorder: InputBorder.none,
                    errorBorder: InputBorder.none,
                    disabledBorder: InputBorder.none,
                    hintText: "API URL (http://123.456.7:123)",
                    hintStyle: TextStyle(color: Colors.grey.withOpacity(0.7))),
              ),
            ),
            Container(
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Colors.white,
                  border: Border.all(color: Colors.grey.shade200, width: 1.0),
                  boxShadow: const [
                    BoxShadow(
                      color: Color.fromRGBO(196, 196, 196, .3),
                      blurRadius: 10,
                      offset: Offset(0, 10),
                    )
                  ]),
              child: TextField(
                style: TextStyle(color: Colors.black),
                controller: controller.institutionidController,
                decoration: InputDecoration(
                    border: InputBorder.none,
                    focusedBorder: InputBorder.none,
                    enabledBorder: InputBorder.none,
                    errorBorder: InputBorder.none,
                    disabledBorder: InputBorder.none,
                    hintText: " institution ID",
                    hintStyle: TextStyle(color: Colors.grey.withOpacity(0.7))),
              ),
            ),
          ],
        ),
      ),
      actions: <Widget>[
        Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            TextButton(
              child: Text(
                "Tamam",
                style: TextStyle(color: Colors.blue),
              ),
              onPressed: () {
                Get.back();
              },
            )
          ],
        ),
      ],
    );
  }
}
