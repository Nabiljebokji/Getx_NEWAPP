import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:tasktracker/controllers/home/home_controller.dart';
import 'package:tasktracker/utils/constants/colors/app_colors.dart';
import 'package:tasktracker/utils/routes/app_routes.dart';
import 'package:tasktracker/utils/services/services.dart';
import 'package:tasktracker/view/widgets/custom_drawer.dart';

class HomeView extends StatelessWidget {
  HomeView({super.key});

  final put = Get.lazyPut(() => HomeController(), fenix: true);
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  final homeController = Get.find<HomeController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: AppColors.lightGrey,
      appBar: AppBar(
        backgroundColor: AppColors.lightGrey,
        elevation: 1,
        title: Text(
          "Ana Sayfa",
          style: TextStyle(color: AppColors.greenish),
        ),
        leading: leadingDrawer(),
      ),
      drawer: CustomDrawer(),
      body: Column(
        children: [],
      ),
    );
  }

  Widget leadingDrawer() {
    return Padding(
      padding: const EdgeInsets.all(4.0),
      child: Material(
        color: AppColors.black,
        child: InkWell(
          borderRadius: BorderRadius.circular(10),
          splashColor: Colors.black,
          onTap: () {
            scaffoldKey.currentState!.openDrawer();
          },
          child: Container(
            decoration: BoxDecoration(
              color: AppColors.greenish,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              Icons.menu_rounded,
            ),
          ),
        ),
      ),
    );
  }
}
