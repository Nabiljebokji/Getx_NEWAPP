import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:get/get.dart';
import 'package:tasktracker/utils/bindings/bindings.dart';
import 'package:tasktracker/utils/config/environment.dart';
import 'package:tasktracker/utils/constants/theme/app_theme.dart';
import 'package:tasktracker/utils/helper/customhttp.dart';
import 'package:tasktracker/utils/localization/changelocal.dart';
import 'package:tasktracker/utils/localization/translation.dart';
import 'package:tasktracker/utils/routes/app_pages.dart';
import 'package:tasktracker/utils/services/services.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await MyServices().initialServices();
  await dotenv.load(fileName: Environment.fileName);
  CustomHttp.authType = AuthType.JwtAuth;

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    LocaleController controller = Get.put(LocaleController());
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      initialBinding: GlobalBinding(),
      theme: AppTheme().customThemeMode,
      getPages: AppPages.getPages,
      locale: controller.language,
      translations: MyTranslation(),
      initialRoute: AppPages.initialRoute,
    );
  }
}
