import 'package:get/get.dart';
import 'package:tasktracker/utils/class/crud.dart';
import 'package:tasktracker/utils/config/environment.dart';
import 'package:tasktracker/utils/helper/logger.dart';
import 'package:tasktracker/utils/services/services.dart';

class HomeData {
  Crud crud;
  HomeData(this.crud);
  MyServices myServiceController = Get.find<MyServices>();

  Future<dynamic> getUserPermissions(String? userId) async {
    Logger.success(Environment.getUserPermissions.toString());

    var response = await crud.getData("${Environment.authLogin}/$userId");

    return response.fold((l) => l, (r) => r);
  }
}
