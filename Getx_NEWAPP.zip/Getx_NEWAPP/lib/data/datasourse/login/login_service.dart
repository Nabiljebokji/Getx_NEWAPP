import 'dart:convert';

import 'package:get/get.dart';
import 'package:tasktracker/data/models/login/login_model.dart';
import 'package:tasktracker/utils/class/crud.dart';
import 'package:tasktracker/utils/config/environment.dart';
import 'package:tasktracker/utils/helper/logger.dart';
import 'package:tasktracker/utils/services/services.dart';

class LoginData {
  Crud crud;
  LoginData(this.crud);
  MyServices myServiceController = Get.find<MyServices>();

  Future<dynamic> postLogin(LoginModel? data) async {
    Logger.success(Environment.authLogin.toString());

    var response =
        await crud.postData(Environment.authLogin, json.encode(data));

    return response.fold((l) => l, (r) => r);
  }

  Future<dynamic> getUserPermissions(String? userId) async {
    var response =
        await crud.getData("${Environment.getUserPermissions}/$userId");

    return response.fold((l) => l, (r) => r);
  }

  Future<dynamic> getRolesToUser(String? userId) async {
    var response = await crud.getData("${Environment.getRolesToUser}/$userId");

    return response.fold((l) => l, (r) => r);
  }

  Future<dynamic> getPersonnelUserIdList(String? userId) async {
    var response = await crud.getData(
        "http://192.168.1.232:1258/api/PersonnelList/GetPersonnelUserIdList?UserId=$userId");
    // await crud.getData("${Environment.getPersonnelUserIdList}$userId");

    return response.fold((l) => l, (r) => r);
  }
}
