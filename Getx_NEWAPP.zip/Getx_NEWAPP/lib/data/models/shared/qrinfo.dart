import 'dart:convert';

QrInfo qrInfoFromJson(String str) => QrInfo.fromJson(json.decode(str));

String qrInfoToJson(QrInfo data) => json.encode(data.toJson());

class QrInfo {
  QrInfo({this.url, this.sabitKurumId, this.userName});

  String? url;
  int? sabitKurumId;
  String? userName;

  factory QrInfo.fromJson(Map<String, dynamic> json) => QrInfo(
        url: json["url"],
        sabitKurumId: json["sabitKurumId"],
        userName: json["userName"],
      );

  Map<String, dynamic> toJson() =>
      {"url": url, "sabitKurumId": sabitKurumId, "userName": userName};
}
