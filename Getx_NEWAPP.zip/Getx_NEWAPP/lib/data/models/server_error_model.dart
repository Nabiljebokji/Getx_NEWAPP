class ServerErrorModel {
  String? id;
  String? title;
  int? status;
  String? message;

  ServerErrorModel({this.id, this.title, this.status, this.message});

  factory ServerErrorModel.fromJson(Map<String, dynamic> json) =>
      ServerErrorModel(
        // id: json['id'],
        title: json['title'],
        status: json['status'],
        message: json['message'],
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'status': status,
        'message': message,
      };
}
