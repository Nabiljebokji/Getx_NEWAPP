class GetUserPermissionsModel {
  List<String>? permissions;

  GetUserPermissionsModel({this.permissions});

  GetUserPermissionsModel.fromJson(Map<String, dynamic> json) {
    permissions = json['permissions'].cast<String>();
  }

  Map<String, dynamic> toJson() => {
        'permissions': permissions,
      };
}
