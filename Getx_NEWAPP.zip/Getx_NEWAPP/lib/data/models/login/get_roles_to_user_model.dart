class GetRolesToUserModel {
  List<String>? userRoles;

  GetRolesToUserModel({this.userRoles});

  GetRolesToUserModel.fromJson(Map<String, dynamic> json) {
    userRoles = json['userRoles'].cast<String>();
  }

  Map<String, dynamic> toJson() => {
        'userRoles': userRoles,
      };
}
