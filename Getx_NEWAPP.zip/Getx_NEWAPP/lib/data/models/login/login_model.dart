class LoginModel {
  String? usernameOrEmail;
  String? password;

  LoginModel({this.usernameOrEmail, this.password});

  LoginModel.fromJson(Map<String, dynamic> json) {
    usernameOrEmail = json['usernameOrEmail'];
    password = json['password'];
  }

  Map<String, dynamic> toJson() => {
        'usernameOrEmail': usernameOrEmail,
        'password': password,
      };
}
