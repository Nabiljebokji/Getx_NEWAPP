// // import 'package:firebase_messaging/firebase_messaging.dart';

// import 'dart:convert';
// import 'dart:io';
// import 'package:awesome_dialog/awesome_dialog.dart';
// import 'package:firebase_messaging/firebase_messaging.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_local_notifications/flutter_local_notifications.dart';
// import 'package:flutter_timezone/flutter_timezone.dart';
// import 'package:karmedbase/karmedbase.dart';
// import 'package:oxipital/bloc/event/firebase_notification_event.dart';
// import 'package:oxipital/bloc/bloc/firebase_notification_bloc.dart';
// import 'package:oxipital/models/dto/patient.dart';
// import 'package:oxipital/models/sivitcare/firebase_fcm_model.dart';
// import 'package:oxipital/utils/helper/logger.dart';
// import 'package:oxipital/utils/resource/globals.dart';
// import 'package:oxipital/views/view/icu/dashboard.dart';
// import 'package:oxipital/views/view/treatment_reminder.dart';
// import 'package:rxdart/rxdart.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:timezone/data/latest_all.dart' as tz;
// import 'package:timezone/timezone.dart' as tz;

// class FirebaseMessageSettings {
//   String? userFullName;
//   String? fCMToken;
//   FirebaseNotificationBloc _firebaseBloc = FirebaseNotificationBloc();
//   FirebaseMessaging messaging = FirebaseMessaging.instance;
//   final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
//       FlutterLocalNotificationsPlugin();

//   static final onClickNotification = BehaviorSubject<String>();

//   subscribeToTopic(String topic) async {
//     await FirebaseMessaging.instance.subscribeToTopic(topic);
//   }

//   unSubscribeToTopic(String topic) async {
//     await FirebaseMessaging.instance.unsubscribeFromTopic(topic);
//   }

//   Future requestNotificationPermisions() async {
//     NotificationSettings settings = await messaging.requestPermission(
//       alert: true,
//       announcement: true,
//       badge: true,
//       carPlay: true,
//       criticalAlert: true,
//       provisional: false,
//       sound: true,
//     );
//     if (settings.authorizationStatus == AuthorizationStatus.authorized) {
//       Logger.success('User granted permission');
//       // FirebaseMessaging.instance.getToken().then((value) {
//       //   fCMToken = PreferenceUtils.getString(Constants.userFCMToken);
//       //   userFullName = PreferenceUtils.getString(Constants.userFullName);

//       //   if (fCMToken == null || fCMToken != value) {
//       //     if (userFullName!.isNotEmpty) {
//       //       PreferenceUtils.setString(Constants.userFCMToken, value!);
//       //       Logger.success(
//       //           "================== NEW FCM TOKEN ==================");
//       //       Logger.success("$value");
//       //       _firebaseBloc.add(CreateAndUpdateFirebaseNotificationEvent(
//       //           firebaseFCMModel:
//       //               FirebaseFCMModel(userName: userFullName, fcmToken: value)));
//       //       Logger.success("userName =$userFullName");
//       //     }
//       //   }
//       // });
//     } else if (settings.authorizationStatus ==
//         AuthorizationStatus.provisional) {
//       Logger.error('${settings.authorizationStatus}');
//       Logger.error('User granted provisional permission');
//     } else {
//       Logger.error('${settings.authorizationStatus}');
//       Logger.error('User declined or has not accepted permission');
//     }
//   }

//   String? getFCMToken() {
//     String? token;
//     FirebaseMessaging.instance.getToken().then((value) {
//       if (value != null) {
//         token = value;
//       }
//       Logger.success("============== FCMToken ==============");
//       Logger.success("FCMToken =${token.toString()}");
//       if (!globalCompleter.isCompleted) {
//         globalCompleter.complete(token);
//       }
//       return token;
//     });
//     return token;
//   }

//   void isRefreshToken() async {
//     messaging.onTokenRefresh.listen((newToken) {
//       userFullName = PreferenceUtils.getString(Constants.userFullName, "");
//       if (userFullName!.isNotEmpty) {
//         Logger.success("              =============NEW FCM TOKEN=============");
//         PreferenceUtils.setString(Constants.userFCMToken, newToken);
//         _firebaseBloc.add(CreateAndUpdateFirebaseNotificationEvent(
//             firebaseFCMModel:
//                 FirebaseFCMModel(userName: userFullName, fcmToken: newToken)));
//         Logger.success("FCM RefreshToken has been added =$newToken");
//       }
//     });
//   }

//   myForegroundMessageHandler(BuildContext context) {
//     //onMessage works onlly if the application is open
//     FirebaseMessaging.onMessage.listen((RemoteMessage message) {
//       RemoteNotification? notification = message.notification;

//       Logger.success("onForeground: title=${notification!.title}");
//       Logger.success("onForeground: body=${notification.body}");
//       Logger.success("onForeground: Data:${message.data.toString()}");

//       if (Platform.isIOS) {
//         forgroundMessage();
//       }

//       if (Platform.isAndroid) {
//         initFireBaceNotification(context, message);
//         showNotification(message);
//       }
//       handleMesssage(context, message);
//     });
//   }

//   void initFireBaceNotification(
//       BuildContext context, RemoteMessage message) async {
//     var androidInitSettings =
//         const AndroidInitializationSettings('@mipmap/ic_launcher');
//     var iosInitSettings = const DarwinInitializationSettings();

//     var initSettings = InitializationSettings(
//         android: androidInitSettings, iOS: iosInitSettings);

//     await flutterLocalNotificationsPlugin.initialize(
//       initSettings,
//       onDidReceiveNotificationResponse:
//           (NotificationResponse notificationResponse) async {
//         handleMesssage(context, message);
//       },
//       onDidReceiveBackgroundNotificationResponse:
//           (NotificationResponse notificationResponse) {
//         handleMesssage(context, message);
//       },
//     );
//   }

//   void initLocalNotification(BuildContext context) async {
//     var androidInitSettings =
//         const AndroidInitializationSettings('@mipmap/ic_launcher');
//     var iosInitSettings = const DarwinInitializationSettings();

//     var initSettings = InitializationSettings(
//         android: androidInitSettings, iOS: iosInitSettings);

//     await flutterLocalNotificationsPlugin.initialize(
//       initSettings,
//       onDidReceiveNotificationResponse: onNotificationTap,
//       onDidReceiveBackgroundNotificationResponse: onNotificationTap,
//     );
//     final NotificationAppLaunchDetails? notificationAppLaunchDetails =
//         await flutterLocalNotificationsPlugin.getNotificationAppLaunchDetails();
//     if (notificationAppLaunchDetails!.notificationResponse != null) {
//       var payload = notificationAppLaunchDetails.notificationResponse!.payload;
//       if (payload != null) {
//         Logger.success("${payload.toString()}");
//         handleLocalMesssage(context, payload);
//       }
//     }
//   }

//   static void onNotificationTap(NotificationResponse notificationResponse) {
//     onClickNotification.add(notificationResponse.payload!);
//   }

//   listenToNotifications(BuildContext context) {
//     onClickNotification.stream.listen((event) {
//       Logger.success("${event.toString()}");
//       if (event.isNotEmpty) {
//         if (event == "BeforeTreatment") {
//           NavigatorHelper.push(context, TreatmentReminder());
//         } else if (event == "") {}
//       }
//     });
//   }

//   void handleLocalMesssage(BuildContext context, String? message) {
//     var screen = message;
//     if (screen != null) {
//       if (screen == "BeforeTreatment") {
//         NavigatorHelper.push(context, TreatmentReminder());
//       } else if (screen == "") {}
//     }
//   }

//   DarwinNotificationDetails darwinNotificationDetails =
//       DarwinNotificationDetails(
//     presentAlert: true,
//     presentBadge: true,
//     presentSound: true,
//     sound: "tone.wav",
//   );
//   Future<void> showNotification(RemoteMessage message) async {
//     AndroidNotificationChannel androidNotificationChannel =
//         AndroidNotificationChannel(
//       message.notification!.android!.channelId.toString(),
//       message.notification!.android!.channelId.toString(),
//       importance: Importance.max,
//       showBadge: true,
//       playSound: true,
//       sound: RawResourceAndroidNotificationSound("tone"),
//     );

//     AndroidNotificationDetails androidNotificationDetails =
//         AndroidNotificationDetails(
//       androidNotificationChannel.id.toString(),
//       androidNotificationChannel.name.toString(),
//       channelDescription: 'Flutter Notifications',
//       importance: Importance.max,
//       priority: Priority.high,
//       playSound: true,
//       ticker: 'ticker',
//       sound: RawResourceAndroidNotificationSound("tone"),
//       icon: '@mipmap/ic_launcher',
//     );

//     NotificationDetails notificationDetails = NotificationDetails(
//       android: androidNotificationDetails,
//       iOS: darwinNotificationDetails,
//     );

//     // Future.delayed(Duration.zero, () {
//     flutterLocalNotificationsPlugin.show(
//         0,
//         message.notification!.title.toString(),
//         message.notification!.body.toString(),
//         notificationDetails);
//     // });
//   }

//   Future forgroundMessage() async {
//     await FirebaseMessaging.instance
//         .setForegroundNotificationPresentationOptions(
//             alert: true, badge: true, sound: true);
//   }

//   Future<void> setupClickedBackgroundMessage(BuildContext context) async {
//     //this works only when they click on the message in background mode only without terminated
//     RemoteMessage? initialMessage =
//         await FirebaseMessaging.instance.getInitialMessage();

//     if (initialMessage != null) {
//       handleMesssage(context, initialMessage);
//     }

//     // this is for when they click on the message in background mode
//     FirebaseMessaging.onMessageOpenedApp.listen((event) {
//       handleMesssage(context, event);
//     });
//   }

//   void handleMesssage(BuildContext context, RemoteMessage message) {
//     Logger.info("In handleMesssage function");
//     var patient = PatientDto.fromJson(json.decode(message.data["patient"]));

//     Logger.warning(patient.toString());
//     if (message.data['goto'] == 'alert') {
//       alertDialog(context, patient, message);
//       // redirect to new screen or take different action based on payload that you receive.
//     }
//   }

//   // void handleMesssageOnForeground(BuildContext context, RemoteMessage message) {
//   //   Logger.info("In handleMesssage function");

//   //   var patient = PatientDto.fromJson(json.decode(message.data["patient"]));
//   //   Logger.warning(patient.toString());
//   //   if (message.data['goto'] == 'alert') {
//   //     alertDialog(context, patient, message);
//   //     // redirect to new screen or take different action based on payload that you receive.
//   //   }
//   // }

//   alertDialog(BuildContext context, PatientDto patient, RemoteMessage message) {
//     AwesomeDialog(
//       context: context,
//       dialogType: DialogType.warning,
//       headerAnimationLoop: true,
//       animType: AnimType.bottomSlide,
//       title: '${message.notification!.title}',
//       desc: '${message.notification!.body}',
//       buttonsTextStyle: const TextStyle(color: Colors.black),
//       btnOkText: "${Translate.inst.text("Tamam")}",
//       btnCancelText: "${Translate.inst.text("Geri")}",
//       showCloseIcon: true,
//       btnCancelOnPress: () {
//         // Navigator.of(context).pop();
//       },
//       btnOkOnPress: () {
//         selectNotificationScreen(context, patient, message);
//       },
//     ).show();
//   }

//   selectNotificationScreen(
//       BuildContext context, PatientDto patient, RemoteMessage message) {
//     if (message.data['screen'] != null) {
//       var screen = message.data['screen'];
//       if (screen == "dashBoard") {
//         NavigatorHelper.push(context, DashBoardScreen(patient: patient));
//       } else if (screen == "") {}
//     } else {
//       return 0;
//     }
//   }

//   void showScheduleNotification({
//     DateTime? dateTime,
//     int? id,
//     String? title,
//     String? body,
//     String? payload,
//   }) async {
//     AndroidNotificationChannel androidNotificationChannel =
//         AndroidNotificationChannel(
//       // message.notification!.android!.channelId.toString(),
//       // message.notification!.android!.channelId.toString(),
//       "id",
//       "name",
//       importance: Importance.max,
//       showBadge: true,
//       playSound: true,
//       // sound: true,
//     );

//     AndroidNotificationDetails androidNotificationDetails =
//         AndroidNotificationDetails(
//       androidNotificationChannel.id.toString(),
//       androidNotificationChannel.name.toString(),
//       channelDescription: 'Flutter Notifications',
//       importance: Importance.max,
//       priority: Priority.high,
//       playSound: true,
//       ticker: 'ticker',
//       icon: '@mipmap/ic_launcher',
//     );

//     DarwinNotificationDetails iosNotificationDetails =
//         DarwinNotificationDetails(
//             presentAlert: true, presentBadge: true, presentSound: true);

//     NotificationDetails notificationDetails = NotificationDetails(
//       android: androidNotificationDetails,
//       iOS: iosNotificationDetails,
//     );
//     tz.initializeTimeZones();
//     final String currentTimeZone = await FlutterTimezone.getLocalTimezone();
//     tz.setLocalLocation(tz.getLocation(currentTimeZone));
//     Logger.success(tz.local.name);
//     Logger.success(
//         "Schedule notification => ${dateTime!.year} ${dateTime.month} ${dateTime.day} ${dateTime.hour} ${dateTime.minute} ");
//     await flutterLocalNotificationsPlugin.zonedSchedule(
//       id!,
//       title,
//       body,
//       // tz.TZDateTime.now(tz.local).add(Duration(seconds: 10)),
//       // tz.TZDateTime(tz.local, 2024, 3, 11, 14, 04),
//       tz.TZDateTime(tz.local, dateTime.year, dateTime.month, dateTime.day,
//           dateTime.hour, dateTime.minute),
//       notificationDetails,
//       uiLocalNotificationDateInterpretation:
//           UILocalNotificationDateInterpretation.absoluteTime,
//       payload: payload,
//       androidAllowWhileIdle: true,
//     );
//   }

//   void cancelNotification(int id) async {
//     await flutterLocalNotificationsPlugin.cancel(id);
//   }

//   void cancelAllNotifications() async {
//     await flutterLocalNotificationsPlugin.cancelAll();
//   }

// // TODO Dont Delete this....Dont Delete the comments
//   // onNewToken(String userFullname) async { //this is to work once evrey time app is open to check if the token is refrehed
//   //   if (justOnce) {
//   //     String? fCMToken = PreferenceUtils.getString(Constants.userFCMToken);
//   //     FirebaseMessageSettings().getFCMToken();
//   //     Future<String> myFuture = globalCompleter.future;
//   //     myFuture.then((value) {
//   //       if (fCMToken.isEmpty || fCMToken != value) {
//   //         FirebaseNotificationBloc _firebaseBloc = FirebaseNotificationBloc();
//   //         _firebaseBloc.add(CreateAndUpdateFirebaseNotificationEvent(
//   //             firebaseFCMModel: FirebaseFCMModel(
//   //                 userName: userFullname, fcmToken: fCMToken)));
//   //       }
//   //     });
//   //     justOnce = false;
//   //   }
//   // }

//   // Future<String?> getFCMToken() {
//   //   Future<String?> token = FirebaseMessaging.instance.getToken();
//   //   Logger.success("get FCMToken = ${token.toString()}");

//   //   return token;
//   // }

// // void main() async {
// //   // Initialize Firebase Messaging
// //   await Firebase.initializeApp();

// //   // Request for FCM token
// //   String token = await FirebaseMessaging.instance.getToken();

// //   // Handle new token
// //   FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
// //   FirebaseMessaging.onTokenRefresh.listen(onNewToken);

// //   // Check whether the retrieved token matches the one on your server for this user's device
// //   final preferences = await SharedPreferences.getInstance();
// //   final tokenStored = preferences.getString('deviceToken') ?? '';
// //   if (tokenStored.isEmpty || tokenStored != token) {
// //     await sendTokenToServer(token);
// //   }
// // }

// // Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
// //   print("Handling a background message: ${message.messageId}");
// // }
// // TODO Dont Delete this....Dont Delete the comments
// }
