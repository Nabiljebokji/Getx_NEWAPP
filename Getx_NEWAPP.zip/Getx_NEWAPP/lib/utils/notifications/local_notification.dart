// import 'dart:async';

// import 'package:flutter_local_notifications/flutter_local_notifications.dart';
// import 'package:oxipital/utils/helper/logger.dart';
// import 'package:flutter_timezone/flutter_timezone.dart';
// import 'package:timezone/data/latest_all.dart' as tz;
// import 'package:timezone/timezone.dart' as tz;

// class LocalNotification {
//   final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
//       FlutterLocalNotificationsPlugin();

//   DarwinNotificationDetails darwinNotificationDetails =
//       DarwinNotificationDetails(
//           presentAlert: true, presentBadge: true, presentSound: true);

//   static onTap(NotificationResponse notificationResponse) async {
//     // Logger.info(notificationResponse.id.toString());
//     // Logger.info(notificationResponse.payload.toString());
//   }

//   Future<void> initNotification() async {
//     AndroidInitializationSettings initializationSettingsAndroid =
//         AndroidInitializationSettings('@mipmap/launcher_icon');

//     var initializationSettingsIOS = DarwinInitializationSettings(
//       requestAlertPermission: true,
//       requestBadgePermission: true,
//       requestSoundPermission: true,
//       onDidReceiveLocalNotification:
//           (int id, String? title, String? body, String? payload) async {
//         // Handle local notification received while app is in foreground
//       },
//     );

//     final InitializationSettings initializationSettings =
//         InitializationSettings(
//             android: initializationSettingsAndroid,
//             iOS: initializationSettingsIOS);

//     await flutterLocalNotificationsPlugin.initialize(
//       initializationSettings,
//       onDidReceiveNotificationResponse: onTap,
//       onDidReceiveBackgroundNotificationResponse: onTap,
//     );
//   }

//   static notificationDetails() {
//     const DarwinNotificationDetails darwinNotificationDetails =
//         DarwinNotificationDetails(
//             presentAlert: true, presentBadge: true, presentSound: true);

//     AndroidNotificationDetails androidNotificationDetails =
//         AndroidNotificationDetails('channelId', 'channelName',
//             channelDescription: 'Flutter Notifications',
//             importance: Importance.max,
//             priority: Priority.high,
//             playSound: true,
//             ticker: 'ticker',
//             sound: RawResourceAndroidNotificationSound(
//                 "tone.mp3".split(".").first));

//     return NotificationDetails(
//       android: androidNotificationDetails,
//       iOS: darwinNotificationDetails,
//     );
//   }

//   static Future showNotification(
//       {int? id, String? title, String? body, String? payload}) async {
//     return await FlutterLocalNotificationsPlugin().show(
//         id!, title, body, await notificationDetails(),
//         payload: "showNotification");
//   }

//   void showRepeatedNotification() async {
//     AndroidNotificationDetails andriod = AndroidNotificationDetails(
//       "2",
//       "repeated notification",
//       importance: Importance.max,
//       priority: Priority.high,
//       playSound: true,
//     );
//     NotificationDetails details = NotificationDetails(
//       android: andriod,
//       iOS: darwinNotificationDetails,
//     );
//     await flutterLocalNotificationsPlugin.periodicallyShow(
//         3, "Repeated notification", "body", RepeatInterval.everyMinute, details,
//         payload: "Playload Data");
//   }

//   void showScheduleNotification(DateTime dateTime) async {
//     AndroidNotificationDetails andriod = AndroidNotificationDetails(
//       "channelId",
//       "channelName",
//       importance: Importance.max,
//       priority: Priority.high,
//     );
//     NotificationDetails details = NotificationDetails(
//       android: andriod,
//       iOS: darwinNotificationDetails,
//     );
//     tz.initializeTimeZones();
//     Logger.success(tz.local.name);
//     final String currentTimeZone = await FlutterTimezone.getLocalTimezone();
//     tz.setLocalLocation(tz.getLocation(currentTimeZone));
//     Logger.success(tz.local.name);
//     Logger.success(
//         " ${dateTime.year} ${dateTime.month} ${dateTime.day} ${dateTime.hour} ${dateTime.minute} ");

//     await flutterLocalNotificationsPlugin.zonedSchedule(
//       5,
//       "Schedule notification",
//       "body",
//       // tz.TZDateTime.now(tz.local).add(Duration(seconds: 10)),
//       // tz.TZDateTime(tz.local, 2024, 3, 11, 14, 04),
//       tz.TZDateTime(tz.local, dateTime.year, dateTime.month, dateTime.day,
//           dateTime.hour, dateTime.minute),
//       details,
//       uiLocalNotificationDateInterpretation:
//           UILocalNotificationDateInterpretation.absoluteTime,
//       payload: "Playload Data",
//       androidAllowWhileIdle: true,
//     );
//   }
// }
