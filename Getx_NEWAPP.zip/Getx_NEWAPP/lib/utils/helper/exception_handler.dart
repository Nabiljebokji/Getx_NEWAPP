import 'package:http/http.dart';

class ResponseHelper {
  static handle(dynamic response) {
    if (response is Response) {
      return response.reasonPhrase;
    }
    if (response['reasonPhrase'] != null) {
      return response['reasonPhrase'];
    } else if (response['body'] != null) {
      return response['body'];
    } else if (response['title'] != null) {
      return response['title'];
    }

    return "Response Helper Unknown Error!!";
  }
}
