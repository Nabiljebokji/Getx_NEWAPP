// ignore_for_file: avoid_print, prefer_interpolation_to_compose_strings

import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tasktracker/utils/config/environment.dart';
import 'package:tasktracker/utils/config/shared_perefernce/shared_preferences.dart';
import 'dart:convert';
import 'dart:io';
import 'package:tasktracker/utils/helper/logger.dart';
import 'package:tasktracker/utils/services/services.dart';

class CustomHttp {
  static AuthType authType = AuthType.JwtAuth;
  static MyServices myServicesController = Get.find<MyServices>();
  static dynamic get(String uri) async {
    return responseParser(await http.get(
      _getApiUrl(uri),
      headers: await _getHeaders(),
    ));
  }

  static dynamic post(String uri, dynamic body) async {
    // print("Post Body =$body");
    Logger.info("Post Body =$body");
    return responseParser(await http.post(
      _getApiUrl(uri),
      headers: await _getHeaders(),
      body: body,
    ));
  }

  static dynamic put(String uri, dynamic body) async {
    // print("Post Body =$body");
    Logger.info("Post Body =$body");

    return responseParser(await http.put(
      _getApiUrl(uri),
      headers: await _getHeaders(),
      body: body,
    ));
  }

  static dynamic delete(String uri) async {
    return responseParser(await http.delete(
      _getApiUrl(uri),
      headers: await _getHeaders(),
    ));
  }

  static responseParser(http.Response response) {
    if (response.statusCode == 200 && response.body.isNotEmpty) {
      return jsonDecode(response.body);
    } else if (response.statusCode == 200 && response.body.isEmpty) {
      return true;
    }
    throw response;
  }

  static _getApiUrl(String end) {
    var baseUrl =
        myServicesController.sharedPreferences!.getString(Environment.apiUrl);

    if (baseUrl == "" || baseUrl!.isEmpty) {
      throw "Ayar bilgisi seçilmemiş!";
    }
    if (end.isEmpty) throw "End Url is Empty!!";
    print("Requested URL=" + (baseUrl + end));
    return Uri.parse(baseUrl + end);
  }

  static _getHeaders() async {
    var header = {
      HttpHeaders.contentTypeHeader: "application/json",
      HttpHeaders.authorizationHeader: getAuth(authType)
    };

    return header;
  }

  static String getAuth(AuthType type) {
    if (type == AuthType.BasicAuth) {
      String? username =
          myServicesController.sharedPreferences!.getString("username");
      String? password =
          myServicesController.sharedPreferences!.getString("password");
      return 'Basic ' + base64Encode(utf8.encode('$username:$password'));
    } else if (type == AuthType.JwtAuth) {
      String? token =
          myServicesController.sharedPreferences!.getString(Environment.token);
      print(token);
      return "Bearer $token";
    }
    throw "Not Implemented Auth Type";
  }

  static String getReasonPhrase(dynamic object) {
    return object.reasonPhrase;
  }
}

enum AuthType { BasicAuth, JwtAuth }
























// import 'dart:convert';
// import 'dart:io';
// import 'package:dio/dio.dart';
// import 'package:karmedbase/resources/constants.dart';
// import 'package:karmedbase/resources/enums/authType.dart';
// import 'package:karmedbase/resources/preferenceUtils.dart';
// import 'package:karmedbase/resources/translation/localization.dart';

// class KarmedHttp {
//   static AuthType authType = AuthType.JwtAuth;

//   static String parseError(e) {
//     return e.statusMessage;
//   }

//   static dynamic post(String url, dynamic data) async {
//     return response(await createDio(authType).post(url, data: data));
//   }

//   static dynamic put(String url, dynamic data) async {
//     return response(await createDio(authType).put(url, data: data));
//   }

//   static dynamic get(String url) async {
//     return response(await createDio(authType).get(url));
//   }

//   static dynamic delete(String url) async {
//     return response(await createDio(authType).delete(url));
//   }

//   static response(Response<dynamic> response) {
//     if (response.statusCode == 200) return response.data;
//     throw response;
//   }
// }

// Dio addInterceptors(Dio dio) {
//   dio.interceptors.add(InterceptorsWrapper(onRequest: (options, handler) {
//     requestInterceptor(options);
//     return handler.next(options);
//   }, onResponse: (response, handler) {
//     responseInterceptor(response);
//     return handler.next(response);
//   }, onError: (DioError e, handler) {
//     errorInterceptor(e);
//     return handler.next(e);
//   }));
//   return dio;
// }

// errorInterceptor(DioError dioError) {
//   print("Dio Error" + dioError.toString());
// }

// responseInterceptor(Response response) {
//   print("Response:${response.data}");
// }

// requestInterceptor(RequestOptions options) {
//   print("Body data : ${options.data} ");
//   print(
//       "Requested Url:${options.baseUrl}${options.path} ${options.headers.toString()}");
// }

// //TODO DIOYU UÇUR
// Dio createDio(AuthType type) {
//   var baseUrl = PreferenceUtils.getString(Constants.apiUrl);

//   if (baseUrl == "" || baseUrl.isEmpty) {
//     throw "Ayar bilgisi seçilmemiş!");
//   }
//   return addInterceptors(
//     Dio(
//       BaseOptions(
//         baseUrl: "$baseUrl",
//         headers: {
//           HttpHeaders.contentTypeHeader: "application/json",
//           HttpHeaders.authorizationHeader: getAuth(type)
//         },
//         connectTimeout: 60000,
//         receiveTimeout: 60000,
//       ),
//     ),
//   );
// }

// String getAuth(AuthType type) {
//   if (type == AuthType.BasicAuth) {
//     String username = PreferenceUtils.getString("username");
//     String password = PreferenceUtils.getString("password");
//     return 'Basic ' + base64Encode(utf8.encode('$username:$password'));
//   } else if (type == AuthType.JwtAuth) {
//     String token = PreferenceUtils.getString(Constants.token);
//     return "Bearer $token";
//   }
//   throw "Not Implemented Auth Type";
// }

// errorParser(dynamic object) {
//   return object.statusMessage;
// }


