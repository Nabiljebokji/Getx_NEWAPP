// dotenv
import 'package:flutter_dotenv/flutter_dotenv.dart';

class Environment {
  static String get fileName => ".env";

  static String get backendBaseName => dotenv.get("BACKENDBASENAME");

  static String get baseName => dotenv.get("BASENAME");

  static String get userName => dotenv.get("USERNAME");

  static String get passWord => dotenv.get("PASSWORD");

  static String get fakeName => dotenv.get("FAKENAME");

  static String get fakePassWord => dotenv.get("FAKEPASSWORD");

  static String get token => dotenv.get("TOKEN");

  static String get accessToken => dotenv.get("ACCESSTOKEN");

  static String get permissions => dotenv.get("PERMISSIONS");

  static String get userRole => dotenv.get("USERROLE");

  static String get refreshToken => dotenv.get("REFRESHTOKEN");

  static String get userId => dotenv.get("USERID");

  static String get customerId => dotenv.get("CUSTOMERID");

  static String get apiUrl => dotenv.get("APIURL");

  static String get sabitKurumId => dotenv.get("SABITKURUMID");

  static String get getUserPermissionURL => dotenv.get("GetUserPermissions");

  static String get getRolesToUserURL => dotenv.get("GetRolesToUser");

  static String get getPersonnelUserIdListURL =>
      dotenv.get("GetPersonnelUserIdListURL");

  static String get authLogin {
    final baseName = dotenv.get("BASENAME");
    final authLogin = dotenv.get("AUTHLOGIN");
    return "${Uri.parse(baseName).resolve(authLogin)}";
  }

  static String get getUserPermissions {
    final baseName = dotenv.get("BASENAME");
    final getUserPermissionURL = dotenv.get("GetUserPermissions");
    return "${Uri.parse(baseName).resolve(getUserPermissionURL)}";
  }

  static String get getRolesToUser {
    final baseName = dotenv.get("BASENAME");
    final getRolesToUserURL = dotenv.get("GetRolesToUser");
    return "${Uri.parse(baseName).resolve(getRolesToUserURL)}";
  }

  static String get getPersonnelUserIdList {
    final baseName = dotenv.get("BASENAME");
    final getPersonnelUserIdListURL = dotenv.get("GetPersonnelUserIdListURL");
    return "${Uri.parse(baseName).resolve(getPersonnelUserIdListURL)}";
  }

  static String get apiURL {
    final baseName = dotenv.get("BACKENDBASENAME");
    final apiPath = dotenv.get("BACKEND_API_PATH");
    return "${Uri.parse(baseName).resolve(apiPath)}/";
  }

  // static String get hereApiUrl {
  //   final baseName = dotenv.get("BACKEND_BASENAME");
  //   final apiPath = dotenv.get("BACKEND_API_PATH");
  //   final hereRouteUrl = dotenv.get("HERE_ROUTE_API_PATH");
  //   return "${Uri.parse(baseName).resolve(apiPath)}$hereRouteUrl";
  // }
}
