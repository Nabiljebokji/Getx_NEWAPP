// import 'package:shared_preferences/shared_preferences.dart';

// class SharedPreferences {
//   static SharedPreferences? sharedPreferences;

//   static Future<SharedPreferences> get _instance async =>
//       sharedPreferences = await SharedPreferences.getInstance();

//   static Future<SharedPreferences> init() async {
//     sharedPreferences = await _instance;
//     return sharedPreferences!;
//   }

//   static String getString(String key, [String? defValue]) {
//     return sharedPreferences!.getString(key) ?? defValue ?? "";
//   }

//   static Future<bool> setString(String key, String value) async {
//     var prefs = await _instance;
//     return prefs.setString(key, value);
//   }

//   static bool getBool(String key, [bool? defValue]) {
//     return sharedPreferences!.getBool(key) ?? defValue ?? false;
//   }

//   static Future<bool> setBool(String key, bool value) async {
//     var prefs = await _instance;
//     return prefs.setBool(key, value);
//   }
// }
