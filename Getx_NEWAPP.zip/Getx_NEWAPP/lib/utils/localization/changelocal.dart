import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:tasktracker/utils/constants/theme/app_theme.dart';
import 'package:tasktracker/utils/services/services.dart';

class LocaleController extends GetxController {
  Locale? language;

  MyServices myServices = Get.find<MyServices>();

  ThemeData appTheme = themeEnglish;

  @override
  void onInit() {
    // requestPermissionNotification();
    // fcmconfig();
    // requestPerLocation();
    String? sharedPrefLang = myServices.sharedPreferences!.getString("lang");
    getSharedPrefLang(sharedPrefLang);
    super.onInit();
  }

  changeLang(String langcode) {
    Locale locale = Locale(langcode);
    myServices.sharedPreferences!.setString("lang", langcode);
    appTheme = langcode == "ar" ? themeArabic : themeEnglish;
    Get.changeTheme(appTheme);
    Get.updateLocale(locale);
  }

  // requestPerLocation() async {
  //   bool serviceEnabled;
  //   LocationPermission permission;
  //   serviceEnabled = await Geolocator.isLocationServiceEnabled();
  //   if (!serviceEnabled) {
  //     return Get.snackbar("تنبيه", "الرجاء تشغيل خدمو تحديد الموقع");
  //   }
  //   permission = await Geolocator.checkPermission();
  //   if (permission == LocationPermission.denied) {
  //     permission = await Geolocator.requestPermission();
  //     if (permission == LocationPermission.denied) {
  //       return Get.snackbar("تنبيه", "الرجاء اعطاء صلاحية الموقع للتطبيق");
  //     }
  //   }

  //   if (permission == LocationPermission.deniedForever) {
  //     // Permissions are denied forever, handle appropriately.
  //     return Get.snackbar("تنبيه", "لا يمكن استعمال التطبيق من دون اللوكيشين");
  //   }
  // }

  getSharedPrefLang(String? sharedPrefLang) {
    switch (sharedPrefLang) {
      case "ar":
        language = const Locale("ar");
        appTheme = themeArabic;
        break;
      case "en":
        language = const Locale("en");
        appTheme = themeEnglish;
        break;
      case "tr":
        language = const Locale("tr");

        appTheme = themeEnglish;
        break;
      default:
        language = Locale(Get.deviceLocale!.languageCode);
        appTheme = themeEnglish;
    }
  }
}
