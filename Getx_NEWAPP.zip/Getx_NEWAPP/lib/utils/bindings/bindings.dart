import 'package:get/get.dart';
import 'package:tasktracker/controllers/home/home_controller.dart';
import 'package:tasktracker/controllers/login/login_controller.dart';
import 'package:tasktracker/utils/class/crud.dart';

class GlobalBinding implements Bindings {
  @override
  void dependencies() async {
    Get.put(Crud());
    // Get.put(AuthService(), permanent: true);
    // Get.lazyPut(() => LoginController(), fenix: true);
    // await Get.putAsync(() => AuthService().init(), permanent: true);
    Get.put(LoginController(), permanent: true);
    Get.lazyPut(() => HomeController(), fenix: true);
  }
}
