// // // dart packages
// // import 'dart:async';
// // import "dart:convert";
// // import 'dart:io' show HttpHeaders, HttpStatus, SocketException;

// // // get
// // import 'package:flutter/foundation.dart' show kDebugMode;
// // import 'package:get/get.dart';
// // import 'package:jwt_decode/jwt_decode.dart';
// // import 'package:signalr_netcore/signalr_client.dart';
// import 'package:get/get.dart';
// import 'package:get/get_state_manager/get_state_manager.dart';
// import 'package:tasktracker/utils/helper/logger.dart';
// import 'package:tasktracker/utils/routes/app_routes.dart';
// import 'package:tasktracker/utils/config/shared_perefernce/token_model.dart';
// // import 'package:touride/utils/config/environment.dart';
// // import 'package:touride/models/auth/new_user_model.dart';
// // import 'package:touride/utils/services/repositories/abstracts/storage_repository.dart';
// // import 'package:touride/utils/services/repositories/concretes/secure_storage_repository.dart';
// // import 'package:touride/utils/routes/app_routes.dart';
// // import 'package:touride/utils/enums/auth/base_http_response_errors.dart';
// // import 'package:touride/utils/extension/string.dart';
// // import 'package:touride/utils/helper/logger.dart';

// // // // http package for requesting to server
// // import 'package:http/http.dart' as http;

// // // // enums

// // // //models
// // import 'package:touride/models/auth/birthdate_model.dart';

// // // //
// // import '../enums/auth/auth_response_errors.dart';

// // // // utils

// // import '../../models/auth/user_model.dart';
// // import '../../models/auth/token_model.dart';

// class AuthService extends GetxService {
//   final RxBool isAuthenticated = false.obs;
//   late final TokenModel tokenModel;
//   Rx<List<Object?>?> likedList = Rx<List<Object?>?>(null);
//   final TokenManager _tokenManager =
//       TokenManager(storageRepository: Secu0reStorageRepository());
//   late UserModel user;
//   Rx<String> userName = "".obs;
//   Rx<String> userLastName = "".obs;
//   // Timer? _tokenExpChecker;

//   final hubConnection = HubConnectionBuilder()
//       .withUrl('http://10.0.2.2:5000/ChatHubs',
//           options: HttpConnectionOptions(requestTimeout: 2000))
//       .withAutomaticReconnect()
//       .build();

//   AuthService() {
//     if (kDebugMode) {
//       user = const UserModel(id: 1, firstName: "John", lastName: "Doe");
//     }
//   }

//   Future<AuthService> init() async {
//     TokenModel? tokenModel = await _tokenManager.getToken();
//     if (tokenModel != null) _processToken(tokenModel);
//     super.onInit();
//     return this;
//   }

//   void connectToServer() async {
//     try {
//       await hubConnection.start();

//       await hubConnection
//           .invoke("OnConnectedAsync", args: [getUserIdInToken()]);

//       Logger.success('${hubConnection.connectionId} connection started.');
//     } catch (e) {
//       Logger.error('Error while establishing SignalR connection: $e');
//     }
//   }

//   bool _processToken(TokenModel tokenModel) {
//     if (tokenModel.isTokenExpired) {
//       isAuthenticated.value = false;
//       _tokenManager.deleteToken();
//       return false;
//     } else {
//       this.tokenModel = tokenModel;
//       isAuthenticated.value = true;
//       final int userId = int.parse(tokenModel.payload["id"]);
//       // TODO: get user data(userId, firstname, lastname) from payload inside the token
//       user = UserModel(id: userId, firstName: "John", lastName: "Doe");
//       _createTokenExpirationCheckerTimer(tokenModel.expiryDate);
//       return true;
//     }
//   }

//   void _createTokenExpirationCheckerTimer(DateTime expiryDate) {
//     return;
//     // _tokenExpChecker?.cancel();

//     // // final expired = DateTime.now().add(const Duration(seconds: 15));
//     // _tokenExpChecker = Timer.periodic(const Duration(seconds: 1), (timer) {
//     //   if (expiryDate.isAfter(DateTime.now())) return;
//     //   // if (expired.isAfter(DateTime.now())) return;

//     //   timer.cancel();
//     //   logout();
//     // });
//   }

//   void updateTokenExpiredDate() {
//     final now = DateTime.now();

//     tokenModel.expiryDate = now;
//     _tokenManager.saveToken(tokenModel);
//   }

//   // #region Auth functions
//   Future<void> logout() async {
//     await _tokenManager.deleteToken();
//     isAuthenticated.value = false;
//     // _tokenExpChecker?.cancel();
//     Get.offAllNamed(AppRoutes.login);
//   }

//   Future<AuthenticationError<Enum>?> register(NewUserModel newUser) async {
//     // genel hata yakalayıcı
//     try {
//       // api'den dönecek cevabı tutacak değişken
//       final http.Response response;

//       // eğer api çalışmıyorsa veya cevap timeout'a uğradıysa SocketException hatası fırlatılıyor, o hata burada yakalanacak
//       try {
//         final body = {
//           "name": newUser.firstName,
//           "lastName": newUser.lastName,
//           "email": newUser.email,
//           "dateOfBirth": BirthDateModel(
//             year: newUser.birthDate!.year,
//             month: newUser.birthDate!.month,
//             day: newUser.birthDate!.day,
//           ).toDDMMYYYY(splitter: "."), //
//           "gender": newUser.gender!.number.toString(),
//           "phone": newUser.phoneNumber!.number,
//           "country": newUser.countryISOCode!,
//           // "language": "",
//           "userPassword": newUser.password!,
//           "passwordConfirm": newUser.passwordConfirm!
//         };

//         // yeni kullanıcı kaydı için api'ye post requesti atılacak...
//         response = await http.post(
//           Uri.parse(Environment.apiURL).resolve("User/register"),
//           headers: {
//             HttpHeaders.contentTypeHeader: 'application/json',
//             HttpHeaders.acceptHeader: 'application/json',
//           },
//           encoding: Encoding.getByName("utf-8"),
//           body: json.encode(body),
//         );
//       } on SocketException catch (e) {
//         Logger.info("[Register API] SockecException: ${e.message}");
//         return AuthenticationError(errors: [BaseHttpError.socketError]);
//       }

//       // api'den dönen cevabın http durum kodu alınıyor
//       final int statusCode = response.statusCode;
//       Logger.info("[Register API] Status code: $statusCode");

//       // Eğer apiden dönen cevap 404 http durum kodu ise
//       if (statusCode == HttpStatus.notFound) {
//         // UYARI: Post http url'imizi kontrol edelim!
//         return AuthenticationError(errors: [BaseHttpError.serviceNotFound]);
//       }
//       // yada 500 http durum kodunu içeriyorsa
//       else if (statusCode == HttpStatus.internalServerError) {
//         // Eğer bu koşula girilirse demektir ki apimizin içinde hatalı çalışan durumlar/yakalanmayan hatalar mevcut.
//         return AuthenticationError(
//             errors: [BaseHttpError.apiInternalServerError]);
//       }
//       // api'den dönen cevap metin olarak ap5lication/json formatını içermeli. Bu yüzden metni dart dilinde map'e çevirmeliyiz.
//       Map<String, dynamic> responseData = {};
//       // NOT: Bazı http durum kodlarında body'e gerek olmayabilir ve içeriği boş olabilir.
//       if (response.body.isNotEmpty) {
//         // Body içerisindeki metin json'a çevirilebiliyor mu diye kontrol etmeliyiz. Aksi taktirde ui programı hata ile sonlanabilir.
//         try {
//           responseData = json.decode(response.body);
//         } on FormatException catch (e) {
//           // Eğer burada bu hata yakalanıyorsa demektir ki apimiz bize yanlış formatta(json olmayan) cevap dönüyor.
//           Logger.info("[Register API] FormatException: ${e.message}");
//         }
//       }
//       Logger.info("[Register API] Response json: $responseData");

//       // eğer api'den dönen cevabın http durum kodu ok(200) değilse mutlaka bir hata vardır...
//       final bool isErrorsReturn = responseData.containsKey("errorEnums") &&
//           responseData["errorEnums"] != null;
//       if (statusCode != HttpStatus.ok || isErrorsReturn) {
//         List<RegisterResponseError>? registerErrors;

//         // dönen cevapta "error" keyi mevcutsa bu key hata enum değerini içeriyordur.
//         //   bu değeri integera çevirip error enumında karşılığını sorgulamalıyız.
//         //   böylece çoklu dili destekleyecek şekilde dillere göre hata mesajları verebiliriz.
//         //   aksi taktirde hata mesajı dönseydi bunu sağlayamazdık.
//         if (isErrorsReturn) {
//           final List<int> errors = (responseData["errorEnums"] as List<dynamic>)
//               .map<int>((error) => error as int)
//               .toList();
//           registerErrors = errors
//               .map((int error) => RegisterResponseError.getByValue(error))
//               .toSet()
//               .toList();
//         }

//         return AuthenticationError(
//           errors: registerErrors ?? [RegisterResponseError.unknownError],
//         );
//       }

//       // program akışı buraya geldiyse yeni kullanıcı kaydı başarıyla sonuçlanmıştır. Bu sebeple bu fonksiyonu çağıran yere hatanın olmadığını null döndürerek cevaplıyoruz.
//       Logger.info("[Register API] New user registered succesfully.");
//       return null;
//     } catch (err) {
//       Logger.info("[Register API] Internal error occured. Error message: $err");
//       return AuthenticationError(errors: [BaseHttpError.internalError]);
//     }
//   }

//   Future<AuthenticationError<LoginResponseError>?> login(
//     String email,
//     String password,
//   ) async {
//     final http.Response response;

//     try {
//       final body = {
//         "email": email,
//         "password": password,
//       };
//       response = await http.post(
//         Uri.parse(Environment.apiURL).resolve("Login/login"),
//         headers: {
//           HttpHeaders.contentTypeHeader: 'application/json',
//           HttpHeaders.acceptHeader: 'application/json',
//         },
//         encoding: Encoding.getByName("utf-8"),
//         body: json.encode(body),
//       );
//     } on SocketException catch (e) {
//       Logger.info("SockecException: $e");
//       return AuthenticationError(errors: [LoginResponseError.socketError]);
//     }

//     final int statusCode = response.statusCode;
//     final Map<String, dynamic> responseData;
//     try {
//       responseData = json.decode(response.body);
//     } catch (err) {
//       return AuthenticationError(errors: [LoginResponseError.unknownError]);
//     }

//     List<LoginResponseError>? loginErrors;
//     if (statusCode == HttpStatus.badRequest) {
//       // statusCode = 400

//       // login başarısız
//       if (responseData["errorEnums"] != null) {
//         final List<int> errors = (responseData["errorEnums"] as List<dynamic>)
//             .map<int>((error) => error as int)
//             .toList();
//         loginErrors = errors
//             .map((int error) => LoginResponseError.getByValue(error))
//             .toSet()
//             .toList();
//       }

//       return AuthenticationError(
//         errors: loginErrors ?? [LoginResponseError.unknownError],
//       );
//     }

//     // login başarılı ama response'da token var mı kontrol edelim.
//     if (responseData["data"] == null) {
//       return AuthenticationError(
//           errors: [LoginResponseError.tokenNotExistOnResponse]);
//     }

//     // login başarılı

//     Map<String, dynamic> header;
//     Map<String, dynamic> payload;
//     final String token;
//     {
//       // handling token
//       token = responseData["data"]["token"];
//       userName.value = responseData["data"]["name"];
//       userLastName.value = responseData["data"]["lastName"];
//       final List<String> tokenParts = token.split(".");
//       if (tokenParts.length != 3) {
//         throw Exception("Token Invalid");
//       }

//       header = jsonDecode(tokenParts[0].decryptBase64);
//       payload = jsonDecode(tokenParts[1].decryptBase64);

//       Logger.info("Token (base64): $token");
//       Logger.info("Token header (decrypted): $header");
//       Logger.info("Token payload (decrypted): $payload");
//       // Logger.info("Token signature (decrypted): ${tokenParts[2].decryptBase64}");
//     }

//     // save token to device storage securely
//     DateTime expiredDate = DateTime.fromMillisecondsSinceEpoch(
//             (payload["exp"] * 1000).toInt(),
//             isUtc: true)
//         .toLocal();

//     TokenModel tokenModel = TokenModel.fromJson(token,
//         {'header': header, 'payload': payload, 'expiryDate': expiredDate});
//     await _tokenManager.saveToken(tokenModel);
//     if (_processToken(tokenModel)) {
//       connectToServer();
//       return null;
//     } else {
//       return AuthenticationError(errors: [LoginResponseError.unknownError]);
//     }
//   }

//   Future<AuthenticationError<SmsVerificationResponseError>?> smsVerification(
//     String identifier,
//     String code,
//   ) async {
//     final body = {"identifier": identifier, "code": code};

//     http.Response response = await http.post(
//       Uri.parse(Environment.apiURL).resolve("sms-verification"),
//       headers: {
//         HttpHeaders.contentTypeHeader: 'application/json',
//         HttpHeaders.acceptHeader: 'application/json',
//       },
//       encoding: Encoding.getByName("utf-8"),
//       body: json.encode(body),
//     );

//     final int statusCode = response.statusCode;
//     final Map<String, dynamic> responseData = json.decode(response.body);

//     List<SmsVerificationResponseError>? smsVerificationErrors;
//     if (statusCode == HttpStatus.notAcceptable) {
//       // statusCode = 406
//       if (responseData.containsKey("error")) {
//         final int? error = int.tryParse(responseData["error"]);
//         if (error != null) {
//           smsVerificationErrors = [
//             SmsVerificationResponseError.getByName(error)
//           ];
//         }
//       }

//       return AuthenticationError(
//         errors: smsVerificationErrors ??
//             [SmsVerificationResponseError.unknownError],
//       );
//     }

//     // Sms doğrulama işlemi başarılı

//     return null;
//   }
//   // #endregion

//   String getUserIdInToken() {
//     String token = tokenModel.token;
//     Map<String, dynamic> decodedToken = Jwt.parseJwt(token);
//     String userId = decodedToken['id'];
//     return userId;
//   }

//   String get getUserNameAndLastname {
//     return '${userName.value} ${userLastName.value}';
//   }
// }

// class TokenManager {
//   static const String _tokenKey = "token";
//   final StorageRepository storageRepository;

//   const TokenManager({required this.storageRepository});

//   Future<void> saveToken(TokenModel tokenModel) async {
//     Map<String, dynamic> json = tokenModel.toJson();
//     json["token"] = tokenModel.token.toBase64();
//     json["header"] =
//         jsonEncode(json["header"] as Map<String, dynamic>).toBase64();
//     json["payload"] =
//         jsonEncode(json["payload"] as Map<String, dynamic>).toBase64();
//     json["expiryDate"] = (json["expiryDate"] as DateTime)
//         .millisecondsSinceEpoch
//         .toString()
//         .toBase64();
//     final jsonString = jsonEncode(json);
//     await storageRepository.write(_tokenKey, jsonString);
//   }

//   Future<void> deleteToken() async {
//     storageRepository.delete(_tokenKey);
//   }

//   Future<TokenModel?> getToken() async {
//     String? storedJsonString = await storageRepository.read(_tokenKey);

//     if (storedJsonString == null) return null;

//     try {
//       Map<String, dynamic> json = jsonDecode(storedJsonString);
//       final String token = (json["token"] as String).decryptBase64;
//       json["header"] = jsonDecode((json["header"] as String).decryptBase64);
//       json["payload"] = jsonDecode((json["payload"] as String).decryptBase64);
//       json["expiryDate"] = DateTime.fromMillisecondsSinceEpoch(
//           int.parse((json["expiryDate"] as String).decryptBase64));
//       TokenModel tokenModel = TokenModel.fromJson(token, json);
//       return tokenModel;
//     } catch (_) {
//       if (kDebugMode) rethrow;
//       return null;
//     }
//   }
// }
