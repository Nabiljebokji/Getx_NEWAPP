import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tasktracker/utils/config/secure_storage/secure_storage.dart';

class MyServices extends GetxService {
  SharedPreferences? sharedPreferences;
  SecureStorage secureStorage = SecureStorage();

  Future<MyServices> init() async {
    sharedPreferences = await SharedPreferences.getInstance();

    return this;
  }

  initialServices() async {
    await Get.putAsync(() => MyServices().init());
  }
}
