enum MapLayerFeature {
  iciness(1),
  wind(2),
  emission(3),
  accident(4),
  temperature(5),
  gravel(6),
  damagedRoad(7),
  dust(8),
  moisture(9),
  mist(10),
  liveLocationSharing(11);

  final int _value;

  const MapLayerFeature(int value) : _value = value;

  int get value => _value;
}
