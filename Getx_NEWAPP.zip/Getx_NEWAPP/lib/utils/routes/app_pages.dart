import 'package:flutter/foundation.dart';

// for page transition
import 'package:get/get.dart';
import 'package:tasktracker/view/home/home_view.dart';
import 'package:tasktracker/view/login/login_view.dart';
import 'app_routes.dart' show AppRoutes;
import '../middlewares/auth_middleware.dart';

final AuthGuardMiddleware _authGuardMiddleware =
    AuthGuardMiddleware(redirectRoute: AppRoutes.login);

class AppPages {
  static const String initialRoute =
      kDebugMode ? AppRoutes.login : AppRoutes.login;

  static List<GetPage> getPages = [
    GetPage(
      name: AppRoutes.login,
      page: () => LoginView(),
      transition: Transition.leftToRight,
      middlewares: kDebugMode
          ? [
              _authGuardMiddleware,
            ]
          : [_authGuardMiddleware],
    ),

    //#region Login Pages

    GetPage(
      name: AppRoutes.home,
      page: () => HomeView(),
      transition: Transition.downToUp,
    ),
  ];
}
