abstract class AppRoutes {
  // auth
  static const login = "/login_view";
  static const home = "/home_view";
}
