import 'package:flutter/material.dart';

class AppColors {
  static const blue = Color(0xFF2287c9);
  static const bluesh = Color.fromARGB(155, 34, 134, 201);
  static const green = Color.fromARGB(189, 0, 118, 4);
  static const greenish = Color.fromARGB(214, 111, 207, 114);
  static const lightGrey = Color.fromARGB(255, 237, 236, 236);
  static const black = Color.fromARGB(0, 0, 0, 0);
  static const transparent = Color(0x00000000);
  static const white = Color.fromARGB(233, 255, 255, 255);
  static const darkred = Color(0xffAB0707);
}
