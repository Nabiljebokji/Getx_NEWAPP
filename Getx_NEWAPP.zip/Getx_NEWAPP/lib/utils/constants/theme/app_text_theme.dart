import 'package:flutter/material.dart';
import 'package:tasktracker/utils/constants/colors/app_colors.dart';

class AppTextStyles {
  AppTextStyles._();

  static const TextStyle base = TextStyle(
    fontFamily: "Mulish",
    fontSize: 13,
    fontWeight: FontWeight.normal,
    color: AppColors.white,
  );

  static const TextStyle white = TextStyle(
    // fontFamily: "",
    fontSize: 16,
    fontWeight: FontWeight.normal,
    color: AppColors.white,
  );
}
