import 'package:flutter/material.dart';
import 'package:tasktracker/utils/constants/colors/app_colors.dart';

class AppTheme {
  final ThemeData customThemeMode = ThemeData.light().copyWith(
    primaryColor: const Color.fromARGB(255, 253, 214, 62),
    colorScheme: ColorScheme.fromSwatch().copyWith(
      secondary: Colors.yellow.shade600,
      error: Colors.red,
    ),
  );
}

ThemeData themeEnglish = ThemeData(
  fontFamily: "PlayfairDisplay",
  floatingActionButtonTheme:
      FloatingActionButtonThemeData(backgroundColor: AppColors.greenish),
  appBarTheme: AppBarTheme(
    centerTitle: true,
    elevation: 0,
    iconTheme: IconThemeData(color: AppColors.greenish),
    titleTextStyle: const TextStyle(
        color: AppColors.greenish,
        fontWeight: FontWeight.bold,
        fontFamily: "PlayfairDisplay",
        fontSize: 25),
    backgroundColor: Colors.grey[50],
  ),
  textTheme: TextTheme(
      displayLarge: TextStyle(
          fontWeight: FontWeight.bold, fontSize: 22, color: AppColors.black),
      displayMedium: TextStyle(
          fontWeight: FontWeight.bold, fontSize: 26, color: AppColors.black),
      bodyLarge: TextStyle(
          height: 2,
          color: AppColors.lightGrey,
          fontWeight: FontWeight.bold,
          fontSize: 14),
      bodyMedium:
          TextStyle(height: 2, color: AppColors.lightGrey, fontSize: 14)),
  primarySwatch: Colors.blue,
);

ThemeData themeArabic = ThemeData(
  fontFamily: "Cairo",
  textTheme: TextTheme(
      displayLarge: TextStyle(
          fontWeight: FontWeight.bold, fontSize: 22, color: AppColors.black),
      displayMedium: TextStyle(
          fontWeight: FontWeight.bold, fontSize: 26, color: AppColors.black),
      bodyLarge: TextStyle(
          height: 2,
          color: AppColors.lightGrey,
          fontWeight: FontWeight.bold,
          fontSize: 14),
      bodyMedium:
          TextStyle(height: 2, color: AppColors.lightGrey, fontSize: 14)),
  primarySwatch: Colors.blue,
);
