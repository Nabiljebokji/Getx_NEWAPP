import 'dart:convert';
import 'package:dartz/dartz.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:tasktracker/data/models/login/login_model.dart';
import 'package:tasktracker/data/models/login/login_response_model.dart';
import 'package:tasktracker/data/models/shared/server_error_model.dart';
import 'package:tasktracker/utils/class/statusrequest.dart';
import 'package:tasktracker/utils/config/environment.dart';
import 'package:tasktracker/utils/functions/checkinternet.dart';
import 'package:http/http.dart' as http;
import 'package:tasktracker/utils/helper/logger.dart';
import 'package:tasktracker/utils/services/services.dart';

class Crud {
  MyServices myServices = Get.find<MyServices>();
  String? baseName;

  Future<Either<dynamic, Map>> postData(String urlLink, var data) async {
    baseName = myServices.sharedPreferences!.getString(Environment.baseName);

    try {
      if (await checkInternet()) {
        if (isTokenExpired()!) {
          await refreshToken();
          Logger.info("              =====TOKEN HAS BEEN REFRESHD=====");
        }

        Logger.info("${Uri.parse(baseName!).resolve(urlLink)}");
        Logger.info(data.toString());
        final response = await http.post(
          Uri.parse(baseName!).resolve(urlLink),
          body: data,
          headers: getHeaders(),
        );
        Logger.warning(response.statusCode.toString());

        if (response.statusCode == 200 || response.statusCode == 201) {
          Map responsebody = jsonDecode(response.body);
          Logger.success(responsebody.toString());

          return Right(responsebody);
        } else {
          return Left(ResponseHelper.handle(response));
        }
      } else {
        return Left(ResponseHelper(
            serverErrorModel:
                ServerErrorModel(message: "No Internet Connection"),
            statusRequest: StatusRequest.offlinefailure));
        // return Left(StatusRequest.offlinefailure);
      }
    } catch (e) {
      debugPrint(e.toString());
      Logger.warning(e.toString());
      return Left(ResponseHelper(
          serverErrorModel: ServerErrorModel(message: "Server Failure"),
          statusRequest: StatusRequest.serverfailure));
    }
  }

  Future<Either<dynamic, Map>> getData(String urlLink) async {
    try {
      if (await checkInternet()) {
        if (isTokenExpired()!) {
          await refreshToken();
          Logger.info("              =====TOKEN HAS BEEN REFRESHD=====");
        }
        Logger.info("${Uri.parse(baseName!).resolve(urlLink)}");
        final response = await http.get(
          Uri.parse(baseName!).resolve(urlLink),
          headers: getHeaders(),
        );
        Logger.warning(response.statusCode.toString());
        Logger.warning(myServices.sharedPreferences!
            .getString(Environment.accessToken)
            .toString());

        if (response.statusCode == 200 || response.statusCode == 201) {
          Map responsebody = jsonDecode(response.body);
          Logger.success(responsebody.toString());

          return Right(responsebody);
        } else {
          return Left(ResponseHelper.handle(response));
        }
      } else {
        return Left(ResponseHelper(
            serverErrorModel:
                ServerErrorModel(message: "No Internet Connection"),
            statusRequest: StatusRequest.offlinefailure));
        // return Left(StatusRequest.offlinefailure);
      }
    } catch (e) {
      Logger.warning(e.toString());
      return Left(ResponseHelper(
          serverErrorModel: ServerErrorModel(message: "Server Failure"),
          statusRequest: StatusRequest.serverfailure));
    }
  }

  Future<Either<dynamic, Map>> updateData(String urlLink, var data) async {
    try {
      if (await checkInternet()) {
        if (isTokenExpired()!) {
          await refreshToken();
          Logger.info("              =====TOKEN HAS BEEN REFRESHD=====");
        }
        Logger.info("${Uri.parse(baseName!).resolve(urlLink)}");
        final response = await http.put(
          Uri.parse(baseName!).resolve(urlLink),
          body: data,
          headers: getHeaders(),
        );
        Logger.warning(response.statusCode.toString());

        if (response.statusCode == 200 || response.statusCode == 201) {
          Map responsebody = jsonDecode(response.body);
          Logger.success(responsebody.toString());

          return Right(responsebody);
        } else {
          return Left(ResponseHelper.handle(response));
        }
      } else {
        return Left(ResponseHelper(
            serverErrorModel:
                ServerErrorModel(message: "No Internet Connection"),
            statusRequest: StatusRequest.offlinefailure));
        // return Left(StatusRequest.offlinefailure);
      }
    } catch (e) {
      Logger.warning(e.toString());
      return Left(ResponseHelper(
          serverErrorModel: ServerErrorModel(message: "Server Failure"),
          statusRequest: StatusRequest.serverfailure));
    }
  }

  Future<Either<dynamic, Map>> deleteData(String urlLink, var data) async {
    try {
      if (await checkInternet()) {
        if (isTokenExpired()!) {
          await refreshToken();
          Logger.info("              =====TOKEN HAS BEEN REFRESHD=====");
        }
        Logger.info("${Uri.parse(baseName!).resolve(urlLink)}");
        final response = await http.delete(
          Uri.parse(baseName!).resolve(urlLink),
          body: data,
          headers: getHeaders(),
        );
        Logger.warning(response.statusCode.toString());

        if (response.statusCode == 200 || response.statusCode == 201) {
          Map responsebody = jsonDecode(response.body);
          Logger.success(responsebody.toString());

          return Right(responsebody);
        } else {
          return Left(ResponseHelper.handle(response));
        }
      } else {
        return Left(ResponseHelper(
            serverErrorModel:
                ServerErrorModel(message: "No Internet Connection"),
            statusRequest: StatusRequest.offlinefailure));
        // return Left(StatusRequest.offlinefailure);
      }
    } catch (e) {
      Logger.warning(e.toString());
      return Left(ResponseHelper(
          serverErrorModel: ServerErrorModel(message: "Server Failure"),
          statusRequest: StatusRequest.serverfailure));
    }
  }

  bool? isTokenExpired() {
    if (myServices.sharedPreferences!.getString(Environment.expiration) !=
        null) {
      return DateTime.now().isAfter(DateTime.tryParse(
          "${myServices.sharedPreferences!.getString(Environment.expiration)}")!);
    } else {
      return false;
    }
  }

  Future<void> refreshToken() async {
    baseName = myServices.sharedPreferences!.getString(Environment.baseName);
    var gg =
        await myServices.secureStorage.readSecureData(Environment.passWord);
    LoginModel? data = LoginModel(
      usernameOrEmail:
          myServices.sharedPreferences!.getString(Environment.userName),
      password: "${gg}",
    );
    // Logger.warning("${json.encode(data)}");
    final response = await http.post(
      Uri.parse(baseName!).resolve(Environment.authLogin),
      body: json.encode(data),
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
      },
    );
    Logger.warning("response.statusCode = ${response.statusCode.toString()}");
    if (response.statusCode == 200 || response.statusCode == 201) {
      Logger.info("              =====TOKEN HAS BEEN REFRESHD=====");

      Map<String, dynamic> responsebody = jsonDecode(response.body);
      List<LoginResponseModel> userList = [];
      userList.add(LoginResponseModel.fromJson(responsebody));
      myServices.sharedPreferences!.setString(
          Environment.accessToken, userList.first.token!.accessToken!);
      myServices.sharedPreferences!.setString(
          Environment.refreshToken, userList.first.token!.refreshToken!);
      myServices.sharedPreferences!.setString(
          Environment.expiration, "${userList.first.token!.expiration!}");
      myServices.sharedPreferences!
          .setString(Environment.userId, userList.first.userId!);
      myServices.sharedPreferences!
          .setString(Environment.customerId, userList.first.customerId!);
    }
  }

  getHeaders() => {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Authorization":
            "Bearer ${myServices.sharedPreferences!.getString(Environment.accessToken)}",
      };
}
