import 'dart:convert';
import 'package:http/http.dart';
import 'package:tasktracker/data/models/shared/server_error_model.dart';
import 'package:tasktracker/utils/helper/logger.dart';

class ResponseHelper {
  ServerErrorModel? serverErrorModel;
  StatusRequest? statusRequest;

  ResponseHelper({this.serverErrorModel, this.statusRequest});

  static handle(dynamic response) {
    if (response is Response) {
      Logger.error(response.body.toString());
      return ResponseHelper(
          serverErrorModel:
              ServerErrorModel.fromJson(jsonDecode(response.body)),
          statusRequest: StatusRequest.failure);
    }
    return "Response Helper Sınıfında Yakalanamayan Hata!!";
  }
}

enum StatusRequest {
  none,
  loading,
  success,
  failure,
  serverfailure,
  serverException,
  offlinefailure
}
