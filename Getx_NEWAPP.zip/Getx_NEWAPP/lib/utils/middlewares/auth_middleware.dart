// flutter package
import 'package:flutter/widgets.dart' show RouteSettings;
// get
import 'package:get/get.dart';
import 'package:tasktracker/utils/routes/app_routes.dart';
// service
import 'package:tasktracker/utils/services/services.dart';

class AuthGuardMiddleware extends GetMiddleware {
  final String redirectRoute;

  AuthGuardMiddleware({required this.redirectRoute});

  @override
  RouteSettings? redirect(String? route) {
    MyServices myServiceController = Get.find<MyServices>();
    // final authService = Get.find<AuthService>();
    // if (!authService.isAuthenticated.value) {//todomake this log in with is AUTHENTICATED SERVICES <3
    //   return const RouteSettings(name: AppRoutes.home);
    // }
    if (myServiceController.sharedPreferences!.getString("id") != null) {
      return const RouteSettings(name: AppRoutes.home);
    }
    return null;
  }

  @override
  int? get priority => -1000;
}
