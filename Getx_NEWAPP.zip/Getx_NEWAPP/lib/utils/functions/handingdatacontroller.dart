import 'package:tasktracker/utils/class/statusrequest.dart';

handlingData(response) {
  if (response is ResponseHelper) {
    return response.statusRequest;
  } else {
    return StatusRequest.success;
  }
}
